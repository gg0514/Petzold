//---------------------------------------------
// FirstProgram.cs (c) 2006 by Charles Petzold
//---------------------------------------------

class FirstProgram
{
    public static void Main() 
    { 
        System.Console.WriteLine("Hello, Microsoft .NET Framework!"); 
    }
}
