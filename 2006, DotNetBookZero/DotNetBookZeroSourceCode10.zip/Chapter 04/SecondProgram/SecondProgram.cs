//----------------------------------------------
// SecondProgram.cs (c) 2006 by Charles Petzold
//----------------------------------------------
using System;

class SecondProgram
{
    public static void Main()
    {
        Console.WriteLine("Hello, Microsoft .NET Framework!");
    }
}
