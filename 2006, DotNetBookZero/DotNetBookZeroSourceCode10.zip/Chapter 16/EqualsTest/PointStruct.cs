//--------------------------------------------
// PointStruct.cs (c) 2006 by Charles Petzold
//--------------------------------------------
struct PointStruct
{
    public int x, y;
}
