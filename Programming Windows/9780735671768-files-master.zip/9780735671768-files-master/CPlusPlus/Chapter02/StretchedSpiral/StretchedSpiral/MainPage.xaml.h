//
// MainPage.xaml.h
// Declaration of the MainPage class.
//

#pragma once

#include "MainPage.g.h"

namespace StretchedSpiral
{
    public ref class MainPage sealed
    {
    public:
        MainPage();
    };
}
